import CreatureAbilities from './util/creature-abilities.js';
import CreatureTemplate from './util/creature-template.js';
import OptionsCreature from './util/options-creature.js';
export default class CreatureModel {
    name: string;
    chars: {
        [char: string]: {
            initial: number;
            advances: number;
        };
    };
    move: string;
    creatureTemplate: CreatureTemplate;
    abilities: CreatureAbilities;
    trappings: Item.Data[];
    spells: Item.Data[];
    prayers: Item.Data[];
    physicalMutations: Item.Data[];
    mentalMutations: Item.Data[];
    options: OptionsCreature;
}
