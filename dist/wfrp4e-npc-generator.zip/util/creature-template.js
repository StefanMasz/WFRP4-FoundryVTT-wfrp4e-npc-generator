export default class CreatureTemplate {
    constructor() {
        this.isSwarm = false;
        this.hasWeaponTrait = false;
        this.hasArmourTrait = false;
    }
}
//# sourceMappingURL=creature-template.js.map