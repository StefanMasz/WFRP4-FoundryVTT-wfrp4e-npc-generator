export declare enum GenerateEffectOptionEnum {
    NONE = "NONE",
    DEFAULT_DISABLED = "DEFAULT_DISABLED",
    DEFAULT_ENABLED = "DEFAULT_ENABLED"
}
export declare function getGenerateEffectOptionEnum(value: string): GenerateEffectOptionEnum;
