export default class NameChooser {
    static selectName(initName: string, speciesKey: string, withRandom: boolean, callback: (name: string) => void, undo?: () => void): Promise<void>;
}
