/// <reference types="jquery" />
import GenerationProfiles from './generation-profiles.js';
export default class GenerationProfilesForm extends FormApplication<GenerationProfiles> {
    private data;
    constructor(object: GenerationProfiles, options?: FormApplication.Options);
    static get defaultOptions(): FormApplication.Options;
    getData(): any;
    activateListeners(html: JQuery): void;
    protected _getSubmitData(_updateData?: object): any;
    _updateObject(_event: Event, formData: any): Promise<void>;
    close(options?: object): Promise<void>;
    private performInputChange;
}
