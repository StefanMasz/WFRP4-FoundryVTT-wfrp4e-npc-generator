export default class TranslateErrorDetect {
    static findActorBySkillIncludes(name: string): Promise<Actor[]>;
    static detectTrappingsTranslateError(callback: (errors: {
        notFounds: string[];
        resolved: string[];
    }) => void): Promise<void>;
    static detectRandomCareerTranslateError(callback: (errors: string[]) => void): Promise<void>;
    static detectSkillsAndTalentsTranslateError(callback: (errors: string[]) => void): Promise<void>;
}
