import CreatureAbilities from './creature-abilities.js';
export default class CreatureAbilitiesChooser {
    static selectCreatureAbilities(initAbilities: CreatureAbilities, callback: (abilities: CreatureAbilities) => void, undo: () => void): Promise<void>;
}
