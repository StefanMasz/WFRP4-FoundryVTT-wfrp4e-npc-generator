export default class MagicsChooser {
    static selectMagics(initSpells: Item.Data[], initPrayers: Item.Data[], callback: (spells: Item.Data[], prayers: Item.Data[]) => void, undo?: () => void): Promise<void>;
    private static getCorrectedLore;
}
