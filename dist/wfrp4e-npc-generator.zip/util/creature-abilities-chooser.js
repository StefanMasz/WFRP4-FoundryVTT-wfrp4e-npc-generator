var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import CreatureAbilities from './creature-abilities.js';
import ReferentialUtil from './referential-util.js';
import EntityUtil from './entity-util.js';
import CompendiumUtil from './compendium-util.js';
import DialogUtil from './dialog-util.js';
import StringUtil from './string-util.js';
import RandomUtil from './random-util.js';
export default class CreatureAbilitiesChooser {
    static selectCreatureAbilities(initAbilities, callback, undo) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            const dialogId = new Date().getTime();
            const swarm = yield CompendiumUtil.getCompendiumSwarmTrait();
            const weapon = yield CompendiumUtil.getCompendiumWeaponTrait();
            const armour = yield CompendiumUtil.getCompendiumArmourTrait();
            const ranged = yield CompendiumUtil.getCompendiumRangedTrait();
            const size = yield CompendiumUtil.getCompendiumSizeTrait();
            const correctDataName = (data, key = 'name') => {
                if (data[key].includes('*')) {
                    data[key] = data[key].replace(/\*/g, '');
                }
                if (data[key].includes('(') && !data[key].includes(')')) {
                    data[key] = data[key] + ')';
                }
            };
            const initSkillsNames = initAbilities.skills.map((s) => s.name);
            const skills = [
                ...initAbilities.skills.sort((s1, s2) => {
                    return s1.name.localeCompare(s2.name);
                }),
                ...[
                    ...(yield ReferentialUtil.getSkillEntities(true))
                        .filter((s) => {
                        return !StringUtil.arrayIncludesDeburrIgnoreCase(initSkillsNames, s.name);
                    })
                        .map((s) => {
                        const data = duplicate(s.data);
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                    ...(yield ReferentialUtil.getCompendiumActorSkills())
                        .filter((s) => {
                        return !StringUtil.arrayIncludesDeburrIgnoreCase(initSkillsNames, s.name);
                    })
                        .map((s) => {
                        const data = duplicate(s);
                        correctDataName(data);
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                ].sort((s1, s2) => {
                    return s1.name.localeCompare(s2.name);
                }),
            ];
            const initTalentsNames = initAbilities.talents.map((t) => t.name);
            const talents = [
                ...initAbilities.talents.sort((t1, t2) => {
                    return t1.name.localeCompare(t2.name);
                }),
                ...[
                    ...(yield ReferentialUtil.getTalentEntities(true))
                        .filter((t) => {
                        return !StringUtil.arrayIncludesDeburrIgnoreCase(initTalentsNames, t.name);
                    })
                        .map((t) => {
                        const data = duplicate(t.data);
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                    ...(yield ReferentialUtil.getCompendiumActorTalents())
                        .filter((t) => {
                        return !StringUtil.arrayIncludesDeburrIgnoreCase(initTalentsNames, t.name);
                    })
                        .map((t) => {
                        const data = duplicate(t);
                        correctDataName(data);
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                ].sort((t1, t2) => {
                    return t1.name.localeCompare(t2.name);
                }),
            ];
            const initTraitsNames = initAbilities.traits.map((t) => t.name);
            const initTraitsDisplayNames = initAbilities.traits.map((t) => t.displayName);
            const traits = [
                ...initAbilities.traits.sort((t1, t2) => {
                    return t1.displayName.localeCompare(t2.displayName);
                }),
                ...[
                    ...(yield ReferentialUtil.getTraitEntities(true))
                        .filter((t) => {
                        return (!EntityUtil.match(t, swarm) &&
                            !EntityUtil.match(t, weapon) &&
                            !EntityUtil.match(t, armour) &&
                            !EntityUtil.match(t, ranged) &&
                            !EntityUtil.match(t, size) &&
                            !StringUtil.arrayIncludesDeburrIgnoreCase(initTraitsNames, t.name));
                    })
                        .map((t) => {
                        const data = duplicate(t.data);
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                    ...(yield ReferentialUtil.getCompendiumActorTraits())
                        .filter((t) => {
                        return (!EntityUtil.match(t, swarm) &&
                            !EntityUtil.match(t, weapon) &&
                            !EntityUtil.match(t, armour) &&
                            !EntityUtil.match(t, ranged) &&
                            !EntityUtil.match(t, size) &&
                            !StringUtil.arrayIncludesDeburrIgnoreCase(initTraitsDisplayNames, t.displayName));
                    })
                        .map((t) => {
                        const data = duplicate(t);
                        correctDataName(data);
                        correctDataName(data, 'displayName');
                        data._id = RandomUtil.getRandomId();
                        return data;
                    }),
                ].sort((t1, t2) => {
                    return t1.name.localeCompare(t2.name);
                }),
            ];
            const skillsId = `creature-abilities-add-remove-skills-${dialogId}`;
            const talentsId = `creature-abilities-add-remove-talents-${dialogId}`;
            const traitsId = `creature-abilities-add-remove-traits-${dialogId}`;
            const speciesMap = duplicate(ReferentialUtil.getSpeciesMap());
            speciesMap['none'] = '';
            new Dialog({
                title: game.i18n.localize('WFRP4NPCGEN.creatures.abilities.select.title'),
                content: `<form>
              
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.basic.label')}
              ${DialogUtil.getInputScript({
                    id: `creature-abilities-basic-${dialogId}`,
                    type: 'checkbox',
                    checked: initAbilities.includeBasicSkills,
                })}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.swarm.label')}
              ${DialogUtil.getInputScript({
                    id: `creature-abilities-swarm-${dialogId}`,
                    type: 'checkbox',
                    checked: initAbilities.isSwarm,
                })}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.weapon.label')}
              ${DialogUtil.getInputScript({
                    id: `creature-abilities-weapon-${dialogId}`,
                    type: 'checkbox',
                    checked: initAbilities.hasWeaponTrait,
                })}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.weapon.damage.label')}
              ${DialogUtil.getInputScript({
                    id: `creature-abilities-weapon-damage-${dialogId}`,
                    type: 'number',
                    initValue: initAbilities.weaponDamage,
                })}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.ranged.label')}
              ${DialogUtil.getInputScript({
                    id: `creature-abilities-ranged-${dialogId}`,
                    type: 'checkbox',
                    checked: initAbilities.hasRangedTrait,
                })}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.ranged.range.label')}
              ${DialogUtil.getInputScript({
                    id: `creature-abilities-ranged-range-${dialogId}`,
                    type: 'number',
                    initValue: initAbilities.rangedRange,
                })}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.ranged.damage.label')}
              ${DialogUtil.getInputScript({
                    id: `creature-abilities-ranged-damage-${dialogId}`,
                    type: 'number',
                    initValue: initAbilities.rangedDamage,
                })}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.armour.label')}
              ${DialogUtil.getInputScript({
                    id: `creature-abilities-armour-${dialogId}`,
                    type: 'checkbox',
                    checked: initAbilities.hasArmourTrait,
                })}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.armour.value.label')}
              ${DialogUtil.getInputScript({
                    id: `creature-abilities-armour-value-${dialogId}`,
                    type: 'number',
                    initValue: initAbilities.armourValue,
                })}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.size.label')}
              ${DialogUtil.getSelectScript(`creature-abilities-size-${dialogId}`, CompendiumUtil.getSizes(), initAbilities.sizeKey)}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.species.label')}
              ${DialogUtil.getSelectScript(`creature-abilities-species-${dialogId}`, speciesMap, initAbilities.speciesKey)}
              </div>
                
            <div class="form-group">
            ${DialogUtil.getSelectAddRemoveScript({
                    id: traitsId,
                    title: 'WFRP4NPCGEN.creatures.abilities.select.traits.title',
                    captions: `
                ${DialogUtil.getLabelScript('WFRP4NPCGEN.name.select.label')}
                ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.traits.included.label', 'max-width: 60px;')}
                ${DialogUtil.getLabelScript('', 'max-width: 38px;')}
                            `,
                    options: EntityUtil.toSelectOption(traits),
                    initValues: (_a = initAbilities === null || initAbilities === void 0 ? void 0 : initAbilities.traits) === null || _a === void 0 ? void 0 : _a.map((t) => {
                        var _a;
                        return {
                            key: t._id,
                            value: (_a = t.displayName) !== null && _a !== void 0 ? _a : t.name,
                            check: t.included,
                        };
                    }),
                    withCheck: true,
                })}
          </div>
          
          <div class="form-group">
          ${DialogUtil.getSelectAddRemoveScript({
                    id: skillsId,
                    title: 'WFRP4NPCGEN.creatures.abilities.select.skills.title',
                    captions: `
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.name.select.label')}
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.advances.label', 'max-width: 80px;')}
            ${DialogUtil.getLabelScript('', 'max-width: 38px;')}
            `,
                    options: EntityUtil.toSelectOption(skills),
                    initValues: (_b = initAbilities === null || initAbilities === void 0 ? void 0 : initAbilities.skills) === null || _b === void 0 ? void 0 : _b.map((s) => {
                        var _a;
                        return {
                            key: s._id,
                            value: (_a = s.displayName) !== null && _a !== void 0 ? _a : s.name,
                            count: s.data.advances.value,
                        };
                    }),
                    withCount: true,
                })}
          </div>
          <div class="form-group">
          ${DialogUtil.getSelectAddRemoveScript({
                    id: talentsId,
                    title: 'WFRP4NPCGEN.creatures.abilities.select.talents.title',
                    captions: `
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.name.select.label')}
            ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.abilities.select.advances.label', 'max-width: 80px;')}
            ${DialogUtil.getLabelScript('', 'max-width: 38px;')}
            `,
                    options: EntityUtil.toSelectOption(talents),
                    initValues: (_c = initAbilities === null || initAbilities === void 0 ? void 0 : initAbilities.talents) === null || _c === void 0 ? void 0 : _c.map((t) => {
                        var _a;
                        return {
                            key: t._id,
                            value: (_a = t.displayName) !== null && _a !== void 0 ? _a : t.name,
                            count: t.data.advances.value,
                        };
                    }),
                    initCount: 1,
                    withCount: true,
                })}
          </div>
              
          </form>
          <script>  
              
              ${DialogUtil.getAddRemoveElementScript()}
                
            </script>
            `,
                buttons: DialogUtil.getDialogButtons(dialogId, (html) => {
                    const abilities = new CreatureAbilities();
                    html
                        .find(`#creature-abilities-basic-${dialogId}`)
                        .each((_i, r) => {
                        abilities.includeBasicSkills = r.checked;
                    });
                    abilities.sizeKey = (html.find(`#creature-abilities-size-${dialogId}`).val());
                    html
                        .find(`#creature-abilities-swarm-${dialogId}`)
                        .each((_i, r) => {
                        abilities.isSwarm = r.checked;
                    });
                    html
                        .find(`#creature-abilities-ranged-${dialogId}`)
                        .each((_i, r) => {
                        abilities.hasRangedTrait = r.checked;
                    });
                    html
                        .find(`#creature-abilities-armour-${dialogId}`)
                        .each((_i, r) => {
                        abilities.hasArmourTrait = r.checked;
                    });
                    html
                        .find(`#creature-abilities-weapon-${dialogId}`)
                        .each((_i, r) => {
                        abilities.hasWeaponTrait = r.checked;
                    });
                    abilities.rangedRange = (html.find(`#creature-abilities-ranged-range-${dialogId}`).val());
                    abilities.rangedDamage = (html.find(`#creature-abilities-ranged-damage-${dialogId}`).val());
                    abilities.weaponDamage = (html.find(`#creature-abilities-weapon-damage-${dialogId}`).val());
                    abilities.armourValue = (html.find(`#creature-abilities-armour-value-${dialogId}`).val());
                    abilities.speciesKey = (html.find(`#creature-abilities-species-${dialogId}`).val());
                    html.find(`.${traitsId}`).each((_i, r) => {
                        const id = r.id;
                        const key = r.value;
                        let included = false;
                        html.find(`#${id}-check`).each((_i1, r1) => {
                            included = r1.checked;
                        });
                        const trait = traits.find((t) => t._id === key);
                        trait.included = included;
                        abilities.traits.push(trait);
                    });
                    html.find(`.${skillsId}`).each((_i, r) => {
                        const id = r.id;
                        const key = r.value;
                        let count = 0;
                        html.find(`#${id}-count`).each((_i1, r1) => {
                            count = Number(r1.value);
                        });
                        const skill = skills.find((s) => s._id === key);
                        skill.data.advances.value = count;
                        abilities.skills.push(skill);
                    });
                    html.find(`.${talentsId}`).each((_i, r) => {
                        const id = r.id;
                        const key = r.value;
                        let count = 0;
                        html.find(`#${id}-count`).each((_i1, r1) => {
                            count = Number(r1.value);
                        });
                        const talent = (talents.find((t) => t._id === key));
                        talent.data.advances.value = count;
                        abilities.talents.push(talent);
                    });
                    callback(abilities);
                }, undo),
                default: 'yes',
            }, {
                resizable: true,
                classes: ['dialog', 'wfrp4e-npc-generator-dialog'],
            }).render(true);
        });
    }
}
//# sourceMappingURL=creature-abilities-chooser.js.map