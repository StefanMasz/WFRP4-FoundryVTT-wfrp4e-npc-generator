var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
export default class FolderUtil {
    static createNamedFolder(name, parent = null) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            if (name == null || name.length === 0) {
                return null;
            }
            let folder = null;
            if (name.includes('/')) {
                let splitedName = name.split('/');
                if (splitedName.length > 3) {
                    splitedName = splitedName.filter((_n, index) => index <= 2);
                    console.warn(`Folder's name trunked to keep only 2 sub-folders maximum : ${splitedName.join('/')}`);
                }
                for (let path of splitedName) {
                    folder = yield FolderUtil.createNamedFolder(path, folder);
                }
            }
            else {
                folder = (_a = game.folders.find((f) => {
                    var _a, _b;
                    return f.data.name === name &&
                        f.data.parent === ((_b = (_a = parent === null || parent === void 0 ? void 0 : parent.data) === null || _a === void 0 ? void 0 : _a._id) !== null && _b !== void 0 ? _b : null);
                })) !== null && _a !== void 0 ? _a : yield Folder.create({
                    name: name,
                    type: 'Actor',
                    parent: (_b = parent === null || parent === void 0 ? void 0 : parent._id) !== null && _b !== void 0 ? _b : null,
                });
            }
            return folder;
        });
    }
}
//# sourceMappingURL=folder-util.js.map