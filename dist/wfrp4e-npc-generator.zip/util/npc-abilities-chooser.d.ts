export default class NpcAbilitiesChooser {
    static selectNpcAbilities(initSkills: Item.Data[], initTalents: Item.Data[], initTraits: Item.Data[], callback: (skills: Item.Data[], talents: Item.Data[], traits: Item.Data[]) => void, undo?: () => void): Promise<void>;
}
