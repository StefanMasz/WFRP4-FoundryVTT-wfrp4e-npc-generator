export var GenerateEffectOptionEnum;
(function (GenerateEffectOptionEnum) {
    GenerateEffectOptionEnum["NONE"] = "NONE";
    GenerateEffectOptionEnum["DEFAULT_DISABLED"] = "DEFAULT_DISABLED";
    GenerateEffectOptionEnum["DEFAULT_ENABLED"] = "DEFAULT_ENABLED";
})(GenerateEffectOptionEnum || (GenerateEffectOptionEnum = {}));
export function getGenerateEffectOptionEnum(value) {
    switch (value) {
        case GenerateEffectOptionEnum.DEFAULT_DISABLED:
            return GenerateEffectOptionEnum.DEFAULT_DISABLED;
        case GenerateEffectOptionEnum.DEFAULT_ENABLED:
            return GenerateEffectOptionEnum.DEFAULT_ENABLED;
        default:
            return GenerateEffectOptionEnum.NONE;
    }
}
//# sourceMappingURL=generate-effect-option.enum.js.map