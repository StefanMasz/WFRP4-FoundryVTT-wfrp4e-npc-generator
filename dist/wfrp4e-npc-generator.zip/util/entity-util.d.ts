export default class EntityUtil {
    static match(item: any, ref: Item & any): boolean;
    static toSelectOption(items: (Item.Data & any)[]): {
        [key: string]: string;
    };
    static toSelectOptionGroup(items: {
        [group: string]: (Item.Data & any)[];
    }): {
        [group: string]: {
            [key: string]: string;
        };
    };
    static toMinimalName(value: string): string;
    static find(name: string, entities: Item[]): Item.Data | null;
    static hasGroupName(name: string): boolean;
}
