import { GenerateEffectOptionEnum } from './generate-effect-option.enum.js';
import { IOptions } from './options-int.js';
export default class Options implements IOptions {
    withClassTrappings: boolean;
    withCareerTrappings: boolean;
    generateMoneyEffect: GenerateEffectOptionEnum;
    generateWeaponEffect: GenerateEffectOptionEnum;
    withGenPathCareerName: any;
    withLinkedToken: any;
    withInitialMoney: any;
    withInitialWeapons: any;
    genPath: string;
    imagePath: string | null;
    tokenPath: string | null;
    editAbilities: any;
    editTrappings: any;
    addMagics: any;
    addMutations: any;
}
