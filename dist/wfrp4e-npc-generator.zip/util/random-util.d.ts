export default class RandomUtil {
    static getRandomBoolean(): boolean;
    static getRandomPositiveNumber(max: number): number;
    static getRandomValue<T>(array: T[], exclude?: T[]): T;
    static getRandomValues<T>(array: T[], nbr: number): T[];
    static getRandomValueScript(): string;
    static getRandomValuesScript(): string;
    static getRandomId(): string;
    private static random;
}
