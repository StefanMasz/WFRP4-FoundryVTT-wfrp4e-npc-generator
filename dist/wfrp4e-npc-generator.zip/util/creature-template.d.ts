export default class CreatureTemplate {
    creatureData: Actor.Data & any;
    size: string;
    swarm: Item.Data & any;
    weapon: Item.Data & any;
    ranged: Item.Data & any;
    armour: Item.Data & any;
    isSwarm: boolean;
    hasWeaponTrait: boolean;
    hasArmourTrait: boolean;
    weaponDamage: string;
    rangedRange: string;
    rangedDamage: string;
    armourValue: string;
}
