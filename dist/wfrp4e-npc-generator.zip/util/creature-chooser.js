var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import ReferentialUtil from './referential-util.js';
import DialogUtil from './dialog-util.js';
import RandomUtil from './random-util.js';
export default class CreatureChooser {
    static selectCreature(initCreature, callback) {
        return __awaiter(this, void 0, void 0, function* () {
            const dialogId = new Date().getTime();
            const creatures = yield ReferentialUtil.getBestiaryEntities();
            const creaturesMap = {};
            const allCreaturesMap = {};
            const allCreaturesImgs = [];
            for (let [groupeKey, actors] of Object.entries(creatures)) {
                creaturesMap[groupeKey] = {};
                for (let actor of actors) {
                    creaturesMap[groupeKey][actor._id] = actor.name;
                    allCreaturesMap[actor._id] = actor.name;
                    allCreaturesImgs.push({
                        _id: actor._id,
                        img: actor.img,
                    });
                }
            }
            new Dialog({
                title: game.i18n.localize('WFRP4NPCGEN.creatures.select.title'),
                content: `<form class="creature-chooser">
              <div class="form-group">
              ${DialogUtil.getButtonScript('WFRP4NPCGEN.common.button.Random', 'random()')}
              </div>
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.creatures.select.label')}
              ${DialogUtil.getSelectOptGrpScript(`select-creatures-${dialogId}`, creaturesMap, undefined, initCreature, 'change()')}
              </div>
              <div class="form-group creature-chooser-img">
                <img id="selected-creature-img-${dialogId}" alt="" src=""/>
              </div>
          </form>
          <script>  
              function random() {
                  const creaturesKeys = [${Object.keys(allCreaturesMap)
                    .map((key) => `"${key}"`)
                    .join(',')}];
                  const randomCreaturesKey = getRandomValue(creaturesKeys);
                  if (randomCreaturesKey != null) {
                      document.getElementById('select-creatures-${dialogId}').value = randomCreaturesKey;
                      change();
                  }
              }
              
              ${RandomUtil.getRandomValueScript()}
              
              function change() {
                  const creaturesImg = [${allCreaturesImgs
                    .map((c) => {
                    return `{ key: "${c._id}", img: "${c.img}" }`;
                })
                    .join(',')}];
                  const creatureKey = document.getElementById('select-creatures-${dialogId}').value;
                  const imgElm = document.getElementById('selected-creature-img-${dialogId}');
                  if (creatureKey != null) {
                      imgElm.src = creaturesImg.find((c) => c.key === creatureKey).img + '?' + new Date().getTime();
                  } else {
                      imgElm.src = '';
                  }
              }
              
              change();
                
            </script>          
            `,
                buttons: DialogUtil.getDialogButtons(dialogId, (html) => {
                    const creaturesKey = (html.find(`#select-creatures-${dialogId}`).val());
                    let creature = null;
                    for (let [_groupeKey, actors] of Object.entries(creatures)) {
                        if (creature == null) {
                            creature = actors.find((c) => c._id === creaturesKey);
                        }
                    }
                    if (creature != null) {
                        callback(creature === null || creature === void 0 ? void 0 : creature.data);
                    }
                }),
                default: 'yes',
            }, {
                resizable: true,
                classes: [
                    'dialog',
                    'wfrp4e-npc-generator-dialog',
                    'wfrp4e-npc-generator-dialog-creature-chooser',
                ],
            }).render(true);
        });
    }
}
//# sourceMappingURL=creature-chooser.js.map