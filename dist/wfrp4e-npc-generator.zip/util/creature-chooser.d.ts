export default class CreatureChooser {
    static selectCreature(initCreature: string, callback: (creature: Actor.Data) => void): Promise<void>;
}
