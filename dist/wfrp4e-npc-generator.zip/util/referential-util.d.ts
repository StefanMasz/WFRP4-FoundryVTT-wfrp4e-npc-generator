export default class ReferentialUtil {
    static readonly sortedSize: string[];
    static getClassTrappings(): {
        [key: string]: string;
    };
    static getClassKeyFromCareer(career: Item.Data): string | undefined;
    static getSpeciesMap(): {
        [key: string]: string;
    };
    static getSubSpeciesMap(): {
        [key: string]: {
            [subKey: string]: {
                name: string;
                skills: string[];
                talents: any[];
            };
        };
    };
    static getSpeciesSubSpeciesMap(speciesKey: string): {
        [key: string]: {
            name: string;
            skills: string[];
            talents: any[];
        };
    } | null;
    static getSpeciesSkillsMap(): {
        [key: string]: string[];
    };
    static getSpeciesTalentsMap(): {
        [key: string]: any[];
    };
    static getRandomTalents(): string[];
    static getWeaponTypes(): {
        melee: string;
        ranged: string;
    };
    static getWeaponGroups(): string[];
    static getWeaponGroupsKey(group: string): string;
    static getMeleeWeaponGroups(): string[];
    static getRangedWeaponGroups(): string[];
    static getBasicWeaponGroups(): string;
    static getCareerEntities(withWorld?: boolean): Promise<Item[]>;
    static getWorldCareers(): Promise<Item[]>;
    static getWorldEntities(type: string): Promise<Item[]>;
    static getWorldActorEntities(type?: string): Promise<Actor[]>;
    static getTrappingEntities(withWorld?: boolean): Promise<Item[]>;
    static getRandomSpeciesCareers(speciesKey: string): Promise<string[]>;
    static getStatusTiers(): any;
    static getAllBasicSkills(): Promise<any>;
    static findSkill(name: string): Promise<Item.Data>;
    static findTalent(name: string): Promise<Item.Data<{}>>;
    static findTrappings(name: string, referentialTrappings?: Item[]): Promise<Item.Data[]>;
    static findTrappingsByWords(name: string, referentialTrappings?: Item[]): Promise<Item.Data<{}>[]>;
    static findTrapping(name: string, referentialTrappings?: Item[], fromWord?: boolean): Promise<Item.Data | null>;
    static getSpeciesCharacteristics(speciesKey: string): Promise<any>;
    static getSpeciesMovement(speciesKey: string): Promise<any>;
    static getAllMoneyItems(): Promise<Item.Data[]>;
    static getActorsEntities(withWorld?: boolean): Promise<{
        [pack: string]: Actor[];
    }>;
    static getBestiaryEntities(withWorld?: boolean): Promise<{
        [pack: string]: Actor[];
    }>;
    static getSkillEntities(withWorld?: boolean): Promise<Item[]>;
    static getTalentEntities(withWorld?: boolean): Promise<Item[]>;
    static getTraitEntities(withWorld?: boolean): Promise<Item[]>;
    static getSpellEntities(withWorld?: boolean): Promise<Item[]>;
    static getPrayerEntities(withWorld?: boolean): Promise<Item[]>;
    static getPhysicalMutationEntities(withWorld?: boolean): Promise<Item[]>;
    static getMentalMutationEntities(withWorld?: boolean): Promise<Item[]>;
    static getCompendiumActorTraits(): Promise<Item.Data<{}>[]>;
    static getCompendiumActorSkills(): Promise<Item.Data<{}>[]>;
    static getCompendiumActorTalents(): Promise<Item.Data<{}>[]>;
}
