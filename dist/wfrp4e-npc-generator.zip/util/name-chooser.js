var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import DialogUtil from './dialog-util.js';
export default class NameChooser {
    static selectName(initName, speciesKey, withRandom, callback, undo) {
        return __awaiter(this, void 0, void 0, function* () {
            const dialogId = new Date().getTime();
            const randomButton = withRandom
                ? `
        <div class="form-group">
          ${DialogUtil.getButtonScript('WFRP4NPCGEN.common.button.Random', 'random()')}
        </div>     
        `
                : '';
            new Dialog({
                title: game.i18n.localize('WFRP4NPCGEN.name.select.title'),
                content: `<form>
              ${randomButton}            
              <div class="form-group">
              ${DialogUtil.getLabelScript('WFRP4NPCGEN.name.select.label')}
              ${DialogUtil.getInputScript({
                    id: `select-name-${dialogId}`,
                    type: 'text',
                    onInput: 'check()',
                    initValue: initName,
                    name: 'select-name',
                })}
              </div>
          </form>
          <script>  
              function check() {
                const name = document.getElementById('select-name-${dialogId}').value;
                const yesButton = document.getElementById('yes-icon-${dialogId}').parentElement;
                yesButton.disabled = name == null || name.length <= 0;    
              }
              function random() {
                  document.getElementById('select-name-${dialogId}').value = generateName('${speciesKey}');
                  check();
              }
              check();
              
              ${DialogUtil.getNameRandomScript()};
            </script>
            `,
                buttons: DialogUtil.getDialogButtons(dialogId, (html) => {
                    const name = html.find(`#select-name-${dialogId}`).val();
                    callback(name);
                }, undo),
                default: 'yes',
            }, {
                resizable: true,
                classes: ['dialog', 'wfrp4e-npc-generator-dialog'],
            }).render(true);
        });
    }
}
//# sourceMappingURL=name-chooser.js.map