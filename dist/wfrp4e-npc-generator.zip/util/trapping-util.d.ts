export default class TrappingUtil {
    static readonly UPDATE_QUANTITY_KEY = "data.quantity.value";
    static readonly UPDATE_SKILL_NAME_KEY = "name";
    static generateMoney(actor: Actor): Promise<void>;
    static generateWeapons(actor: Actor): Promise<void>;
}
