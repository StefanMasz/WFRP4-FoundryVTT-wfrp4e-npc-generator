export default class MutationsChooser {
    static selectMutations(initPhysicals: Item.Data[], initMentals: Item.Data[], callback: (physicals: Item.Data[], mentals: Item.Data[]) => void, undo?: () => void): Promise<void>;
}
