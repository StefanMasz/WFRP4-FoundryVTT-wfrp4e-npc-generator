export default class TrappingChooser {
    static selectTrappings(initTrappings: Item.Data[], callback: (trappings: Item.Data[]) => void, undo?: () => void): Promise<void>;
}
