import { IOptions } from './options-int.js';
import { GenerateEffectOptionEnum } from './generate-effect-option.enum.js';
export default class OptionsCreature implements IOptions {
    withClassTrappings: boolean;
    withCareerTrappings: boolean;
    generateMoneyEffect: GenerateEffectOptionEnum;
    generateWeaponEffect: GenerateEffectOptionEnum;
    withGenPathCareerName: boolean;
    withLinkedToken: any;
    withInitialMoney: any;
    withInitialWeapons: boolean;
    genPath: string;
    imagePath: string | null;
    tokenPath: string | null;
    editAbilities: boolean;
    editTrappings: any;
    addMagics: any;
    addMutations: any;
}
