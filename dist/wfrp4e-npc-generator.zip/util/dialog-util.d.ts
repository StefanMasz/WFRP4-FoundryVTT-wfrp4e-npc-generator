/// <reference types="jquery" />
import { GenerateEffectOptionEnum } from './generate-effect-option.enum.js';
export default class DialogUtil {
    static getDialogButtons(id: number, yesCallback: (html?: JQuery) => void, previousCallback?: (html?: JQuery) => void): any;
    static getButtonScript(label: string, onclick: string): string;
    static getLabelScript(label: string, style?: string): string;
    static getSelectScript(id: string, options: {
        [key: string]: string;
    }, initValue?: string, onChange?: string, style?: string): string;
    static getSelectOptGrpScript(id: string, options: {
        [group: string]: {
            [key: string]: string;
        };
    }, sort?: (a: [groupKey: string, group: {
        [key: string]: string;
    }], b: [groupKey: string, group: {
        [key: string]: string;
    }]) => number, initValue?: string, onChange?: string, style?: string): string;
    static getInputScript(options: {
        id: string;
        type: string;
        initValue?: string | number | boolean;
        name?: string;
        onInput?: string;
        onClick?: string;
        outerDataListId?: string;
        dataListId?: string;
        options?: string[];
        classes?: string;
        style?: string;
        checked?: boolean;
    }): string;
    static getToArrayScript(): string;
    static getNameRandomScript(): string;
    static getEffectSelectScript(dialogId: number, id: string, initValue: GenerateEffectOptionEnum): string;
    static getFilePickerButton(target: string, type: string): string;
    static browseFileScript(): string;
    static getSelectAddRemoveScript(options: {
        id: string;
        initValues: {
            key: string;
            value: string;
            check?: boolean;
            count?: number;
            withText?: boolean;
            text?: string;
        }[];
        options?: {
            [key: string]: string;
        };
        optionGroups?: {
            [group: string]: {
                [key: string]: string;
            };
        };
        sort?: (a: [groupKey: string, group: {
            [key: string]: string;
        }], b: [groupKey: string, group: {
            [key: string]: string;
        }]) => number;
        title?: string;
        captions?: string;
        withCheck?: boolean;
        withCount?: boolean;
        initCount?: number;
        withText?: boolean;
    }): string;
    static getRemovableItemScript(options: {
        id: string;
        item: {
            key: string;
            value: string;
            check?: boolean;
            count?: number;
            withText?: boolean;
            text?: string;
        };
        withCheck?: boolean;
        withCount?: boolean;
        withText?: boolean;
    }): string;
    static getAddRemoveElementScript(): string;
}
