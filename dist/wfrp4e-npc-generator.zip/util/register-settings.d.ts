export default class RegisterSettings {
    static moduleName: string;
    static initSettings(): void;
    private static registerSettings;
}
