export default class SpeciesChooser {
    static selectSpecies(initSpeciesKey: string, initSubSpeciesKey: string, initCityBorn: string, callback: (speciesKey: string, speciesValue: string, subSpeciesKey: string, cityBorn: string) => void): Promise<void>;
}
