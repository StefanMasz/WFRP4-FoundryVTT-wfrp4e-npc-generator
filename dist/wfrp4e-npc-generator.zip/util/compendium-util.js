var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import WaiterUtil from './waiter-util.js';
export default class CompendiumUtil {
    static initCompendium(callback, forCreatures = false) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.compendiumLoaded || !this.creatureCompendiumLoaded) {
                yield WaiterUtil.show('WFRP4NPCGEN.compendium.load.title', 'WFRP4NPCGEN.compendium.load.hint', () => __awaiter(this, void 0, void 0, function* () {
                    if (forCreatures) {
                        yield Promise.all([
                            this.getCompendiumItems(),
                            this.getCompendiumActors(),
                        ]);
                        yield Promise.all([
                            this.getCompendiumTrappings(),
                            this.getCompendiumBestiary(),
                            this.getCompendiumSkills(),
                            this.getCompendiumTalents(),
                            this.getCompendiumTraits(),
                        ]);
                        yield Promise.all([
                            this.getCompendiumSizeTrait(),
                            this.getCompendiumSwarmTrait(),
                            this.getCompendiumWeaponTrait(),
                            this.getCompendiumArmourTrait(),
                            this.getCompendiumRangedTrait(),
                        ]);
                    }
                    else {
                        yield this.getCompendiumItems();
                        yield Promise.all([
                            this.getCompendiumCareers(),
                            this.getCompendiumTrappings(),
                        ]);
                        yield this.getCompendiumCareersGroups();
                    }
                    if (!this.compendiumLoaded || !this.creatureCompendiumLoaded) {
                        yield WaiterUtil.hide();
                    }
                    if (forCreatures) {
                        this.creatureCompendiumLoaded = true;
                    }
                    else {
                        this.compendiumLoaded = true;
                    }
                    callback();
                }));
            }
            else {
                callback();
            }
        });
    }
    static getCompendiumItems() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumItems == null) {
                this.compendiumItems = [];
                const itemsPacks = game.packs.filter((p) => p.metadata.entity === 'Item');
                const loaders = [];
                for (let pack of itemsPacks) {
                    loaders.push(pack.getContent());
                }
                const contents = yield Promise.all(loaders);
                for (let items of contents) {
                    this.compendiumItems.push(...items);
                }
            }
            return Promise.resolve(this.compendiumItems);
        });
    }
    static getCompendiumActors() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumActors == null) {
                this.compendiumActors = {};
                const actorsPacks = game.packs.filter((p) => p.metadata.entity === 'Actor');
                const packLoader = (pack) => {
                    return new Promise((resolve) => __awaiter(this, void 0, void 0, function* () {
                        var _a, _b, _c;
                        const module = game.modules.get(pack.metadata.package);
                        let key = pack.metadata.label;
                        if (key === pack.metadata.name) {
                            key = (_c = (_b = (_a = module === null || module === void 0 ? void 0 : module.packs) === null || _a === void 0 ? void 0 : _a.find((p) => p.name === pack.metadata.name)) === null || _b === void 0 ? void 0 : _b.label) !== null && _c !== void 0 ? _c : pack.metadata.label;
                        }
                        console.info(`Start to load ${key} compendium`);
                        const actors = (yield pack.getContent()).sort((c1, c2) => {
                            return c1.name.localeCompare(c2.name);
                        });
                        if (actors.length > 0) {
                            this.compendiumActors[key] = actors;
                        }
                        console.info(`End to load ${key} compendium`);
                        resolve();
                    }));
                };
                const loaders = [];
                for (let pack of actorsPacks) {
                    loaders.push(packLoader(pack));
                }
                yield Promise.all(loaders);
            }
            return Promise.resolve(this.compendiumActors);
        });
    }
    static getCompendiumCareers() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumCareers == null) {
                this.compendiumCareers = [];
                this.compendiumCareers.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'career'));
            }
            return Promise.resolve(this.compendiumCareers);
        });
    }
    static getCompendiumCareersGroups() {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumCareerGroups == null) {
                this.compendiumCareerGroups = [];
                const careers = yield this.getCompendiumCareers();
                for (let career of careers) {
                    const group = (_c = (_b = (_a = career === null || career === void 0 ? void 0 : career.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.careergroup) === null || _c === void 0 ? void 0 : _c.value;
                    if (group != null && !this.compendiumCareerGroups.includes(group)) {
                        this.compendiumCareerGroups.push(group);
                    }
                }
            }
            return Promise.resolve(this.compendiumCareerGroups);
        });
    }
    static getTrappingCategories() {
        return Object.keys(game.wfrp4e.config.trappingCategories);
    }
    static getCompendiumTrappings() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumTrappings == null) {
                this.compendiumTrappings = [];
                const trappingCategories = CompendiumUtil.getTrappingCategories();
                this.compendiumTrappings.push(...(yield this.getCompendiumItems()).filter((t) => {
                    var _a, _b, _c;
                    const type = (_c = (_b = (_a = t === null || t === void 0 ? void 0 : t.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.trappingType) === null || _c === void 0 ? void 0 : _c.value;
                    return (trappingCategories.includes(t.type) ||
                        trappingCategories.includes(type));
                }));
            }
            return Promise.resolve(this.compendiumTrappings);
        });
    }
    static getCompendiumBestiary() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumBestiary == null) {
                this.compendiumBestiary = {};
                const actorsMap = yield this.getCompendiumActors();
                for (let [key, actors] of Object.entries(actorsMap)) {
                    const creatures = actors.filter((c) => { var _a; return ((_a = c.data) === null || _a === void 0 ? void 0 : _a.type) === 'creature'; });
                    if (creatures.length > 0) {
                        this.compendiumBestiary[key] = creatures;
                    }
                }
            }
            return Promise.resolve(this.compendiumBestiary);
        });
    }
    static getCompendiumSkills() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumSkills == null) {
                this.compendiumSkills = [];
                this.compendiumSkills.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'skill'));
            }
            return Promise.resolve(this.compendiumSkills);
        });
    }
    static getCompendiumTalents() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumTalents == null) {
                this.compendiumTalents = [];
                this.compendiumTalents.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'talent'));
            }
            return Promise.resolve(this.compendiumTalents);
        });
    }
    static getCompendiumTraits() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumTraits == null) {
                this.compendiumTraits = [];
                this.compendiumTraits.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'trait'));
            }
            return Promise.resolve(this.compendiumTraits);
        });
    }
    static getCompendiumSizeTrait() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumSizeTrait == null) {
                this.compendiumSizeTrait = ((yield this.getCompendiumTraits()).find((t) => t.data.name === 'Size' || t.data.originalName === 'Size'));
            }
            return Promise.resolve(this.compendiumSizeTrait);
        });
    }
    static getCompendiumSwarmTrait() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumSwarmTrait == null) {
                this.compendiumSwarmTrait = ((yield this.getCompendiumTraits()).find((t) => t.data.name === 'Swarm' || t.data.originalName === 'Swarm'));
            }
            return Promise.resolve(this.compendiumSwarmTrait);
        });
    }
    static getCompendiumWeaponTrait() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumWeaponTrait == null) {
                this.compendiumWeaponTrait = ((yield this.getCompendiumTraits()).find((t) => t.data.name === 'Weapon' || t.data.originalName === 'Weapon'));
            }
            return Promise.resolve(this.compendiumWeaponTrait);
        });
    }
    static getCompendiumArmourTrait() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumArmorTrait == null) {
                this.compendiumArmorTrait = ((yield this.getCompendiumTraits()).find((t) => t.data.name === 'Armour' || t.data.originalName === 'Armour'));
            }
            return Promise.resolve(this.compendiumArmorTrait);
        });
    }
    static getCompendiumRangedTrait() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumRangedTrait == null) {
                this.compendiumRangedTrait = ((yield this.getCompendiumTraits()).find((t) => {
                    var _a;
                    return t.data.name.startsWith('Ranged') || ((_a = t.data.originalName) === null || _a === void 0 ? void 0 : _a.startsWith('Ranged'));
                }));
            }
            return Promise.resolve(this.compendiumRangedTrait);
        });
    }
    static getSizes() {
        return game.wfrp4e.config.actorSizes;
    }
    static getCompendiumSpells() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumSpells == null) {
                this.compendiumSpells = [];
                this.compendiumSpells.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'spell'));
            }
            return Promise.resolve(this.compendiumSpells);
        });
    }
    static getCompendiumPrayers() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumPrayers == null) {
                this.compendiumPrayers = [];
                this.compendiumPrayers.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'prayer'));
            }
            return Promise.resolve(this.compendiumPrayers);
        });
    }
    static getCompendiumPhysicalMutations() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumPhysicalMutations == null) {
                this.compendiumPhysicalMutations = [];
                this.compendiumPhysicalMutations.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'mutation' &&
                    c.data.data.mutationType.value === 'physical'));
            }
            return Promise.resolve(this.compendiumPhysicalMutations);
        });
    }
    static getCompendiumMentalMutations() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compendiumMentalMutations == null) {
                this.compendiumMentalMutations = [];
                this.compendiumMentalMutations.push(...(yield this.getCompendiumItems()).filter((c) => c.type === 'mutation' &&
                    c.data.data.mutationType.value === 'mental'));
            }
            return Promise.resolve(this.compendiumMentalMutations);
        });
    }
}
CompendiumUtil.compendiumLoaded = false;
CompendiumUtil.creatureCompendiumLoaded = false;
//# sourceMappingURL=compendium-util.js.map