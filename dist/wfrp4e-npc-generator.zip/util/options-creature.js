import { GenerateEffectOptionEnum, getGenerateEffectOptionEnum, } from './generate-effect-option.enum.js';
import RegisterSettings from './register-settings.js';
export default class OptionsCreature {
    constructor() {
        this.withClassTrappings = false;
        this.withCareerTrappings = false;
        this.generateMoneyEffect = getGenerateEffectOptionEnum(game.settings.get(RegisterSettings.moduleName, 'defaultCreatureGenerateMoneyEffect'));
        this.generateWeaponEffect = GenerateEffectOptionEnum.NONE;
        this.withGenPathCareerName = false;
        this.withLinkedToken = game.settings.get(RegisterSettings.moduleName, 'defaultCreatureWithLinkedToken');
        this.withInitialMoney = game.settings.get(RegisterSettings.moduleName, 'defaultCreatureWithInitialMoney');
        this.withInitialWeapons = false;
        this.genPath = game.settings.get(RegisterSettings.moduleName, 'defaultCreatureGenPath');
        this.imagePath = null;
        this.tokenPath = null;
        this.editAbilities = false;
        this.editTrappings = game.settings.get(RegisterSettings.moduleName, 'defaultCreatureEditTrappings');
        this.addMagics = game.settings.get(RegisterSettings.moduleName, 'defaultCreatureAddMagics');
        this.addMutations = game.settings.get(RegisterSettings.moduleName, 'defaultCreatureAddMutations');
    }
}
//# sourceMappingURL=options-creature.js.map