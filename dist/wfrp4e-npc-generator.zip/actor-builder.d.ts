import NpcModel from './npc-model.js';
export declare class ActorBuilder {
    static buildActorData(model: NpcModel, type: string): Promise<any>;
    static createActor(model: NpcModel, data: any): Promise<Actor<{}, Item<{}>>>;
    private static addGenerateTokenEffect;
}
