var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import NpcGenerator from './npc-generator.js';
import TrappingUtil from './util/trapping-util.js';
import RegisterSettings from './util/register-settings.js';
import CreatureGenerator from './creature-generator.js';
Hooks.once('init', () => {
    game.wfrp4e.npcGen = NpcGenerator;
    game.wfrp4e.creatureGen = CreatureGenerator;
    RegisterSettings.initSettings();
});
Hooks.on('renderActorDirectory', (_app, html) => {
    if (game.user.can('ACTOR_CREATE')) {
        addActorActionButton(html, 'WFRP4NPCGEN.creature.directory.button', () => {
            CreatureGenerator.generateCreature();
        });
        addActorActionButton(html, 'WFRP4NPCGEN.actor.directory.button', () => {
            NpcGenerator.generateNpc();
        });
    }
});
Hooks.on('createToken', (scene, token) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const actor = (_a = game.actors) === null || _a === void 0 ? void 0 : _a.tokens[token._id];
    if ((token === null || token === void 0 ? void 0 : token.actorLink) || actor == null) {
        return;
    }
    const generateMoneyEffect = actor.effects.find((eff) => eff.data.label === game.i18n.localize('WFRP4NPCGEN.trappings.money.label'));
    const generateWeaponEffect = actor.effects.find((eff) => eff.data.label ===
        game.i18n.localize('WFRP4NPCGEN.trappings.weapon.label'));
    const updateScene = (generateMoneyEffect != null && !generateMoneyEffect.data.disabled) ||
        (generateWeaponEffect != null && !generateWeaponEffect.data.disabled);
    if (generateMoneyEffect != null && !generateMoneyEffect.data.disabled) {
        yield TrappingUtil.generateMoney(actor);
    }
    if (generateWeaponEffect != null && !generateWeaponEffect.data.disabled) {
        yield TrappingUtil.generateWeapons(actor);
    }
    if (updateScene) {
        yield scene.updateEmbeddedEntity('Token', actor);
    }
}));
function addActorActionButton(html, label, onClick) {
    const button = document.createElement('button');
    button.style.width = '95%';
    button.innerHTML = game.i18n.localize(label);
    button.addEventListener('click', () => {
        onClick();
    });
    html.find('.header-actions').after(button);
}
//# sourceMappingURL=main.js.map