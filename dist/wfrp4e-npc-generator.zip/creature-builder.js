var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import FolderUtil from './util/folder-util.js';
import TrappingUtil from './util/trapping-util.js';
import { GenerateEffectOptionEnum } from './util/generate-effect-option.enum.js';
import CompendiumUtil from './util/compendium-util.js';
import StringUtil from './util/string-util.js';
export default class CreatureBuilder {
    static buildCreatureData(model) {
        var _a, _b, _c, _d, _e;
        return __awaiter(this, void 0, void 0, function* () {
            const actorData = {
                name: model.name,
                type: 'creature',
                flags: {
                    autoCalcRun: true,
                    autoCalcWalk: true,
                    autoCalcWounds: true,
                    autoCalcCritW: true,
                    autoCalcCorruption: true,
                    autoCalcEnc: true,
                    autoCalcSize: true,
                },
                data: {
                    characteristics: model.chars,
                    details: {
                        move: {
                            value: model.creatureTemplate.creatureData.data.details.move.value,
                        },
                        size: {
                            value: model.abilities.sizeKey,
                        },
                        species: {
                            value: (_a = model.creatureTemplate.creatureData.data.details.species) === null || _a === void 0 ? void 0 : _a.value,
                        },
                        biography: {
                            value: (_b = model.creatureTemplate.creatureData.data.details.biography) === null || _b === void 0 ? void 0 : _b.value,
                        },
                        gender: {
                            value: (_c = model.creatureTemplate.creatureData.data.details.gender) === null || _c === void 0 ? void 0 : _c.value,
                        },
                        hitLocationTable: {
                            value: (_d = model.creatureTemplate.creatureData.data.details.hitLocationTable) === null || _d === void 0 ? void 0 : _d.value,
                        },
                        status: {
                            value: (_e = model.creatureTemplate.creatureData.data.details.status) === null || _e === void 0 ? void 0 : _e.value,
                        },
                    },
                },
                img: model.options.imagePath,
            };
            return Promise.resolve(actorData);
        });
    }
    static createCreature(model, data) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
        return __awaiter(this, void 0, void 0, function* () {
            if (((_b = (_a = model === null || model === void 0 ? void 0 : model.options) === null || _a === void 0 ? void 0 : _a.genPath) === null || _b === void 0 ? void 0 : _b.length) > 0) {
                const genPaths = (_c = model === null || model === void 0 ? void 0 : model.options) === null || _c === void 0 ? void 0 : _c.genPath.split('/').filter((p) => p != null && p.length > 0);
                const folder = yield FolderUtil.createNamedFolder(genPaths.join('/'));
                data.folder = folder === null || folder === void 0 ? void 0 : folder._id;
            }
            let actor = yield Actor.create(data);
            if (model.abilities.skills.length > 0) {
                yield actor.createOwnedItem(model.abilities.skills);
            }
            if (model.abilities.talents.length > 0) {
                yield actor.createOwnedItem(model.abilities.talents);
            }
            if (model.abilities.traits.length > 0) {
                yield actor.createOwnedItem(model.abilities.traits);
            }
            const weapon = yield CompendiumUtil.getCompendiumWeaponTrait();
            const ranged = yield CompendiumUtil.getCompendiumRangedTrait();
            const swarm = yield CompendiumUtil.getCompendiumSwarmTrait();
            const armour = yield CompendiumUtil.getCompendiumArmourTrait();
            const excludedTraitIds = model.abilities.traits
                .filter((t) => !t.included)
                .map((t) => {
                var _a;
                let actorTrait;
                if (weapon.name === t.name) {
                    actorTrait = actor.data.traits.find((at) => at.name === weapon.name);
                }
                else if (StringUtil.getSimpleName(ranged.name) ===
                    StringUtil.getSimpleName(t.name)) {
                    actorTrait = actor.data.traits.find((at) => StringUtil.getSimpleName(at.name) ===
                        StringUtil.getSimpleName(ranged.name));
                }
                else if (swarm.name === t.name) {
                    actorTrait = actor.data.traits.find((at) => at.name === swarm.name);
                }
                else if (armour.name === t.name) {
                    actorTrait = actor.data.traits.find((at) => at.name === armour.name);
                }
                else {
                    actorTrait = actor.data.traits.find((at) => at.displayName === t.displayName);
                }
                return (_a = actorTrait === null || actorTrait === void 0 ? void 0 : actorTrait._id) !== null && _a !== void 0 ? _a : t._id;
            });
            if (excludedTraitIds.length > 0) {
                actor = (yield actor.update({
                    'data.excludedTraits': excludedTraitIds,
                }));
            }
            if (model.trappings.length > 0) {
                yield actor.createOwnedItem(model.trappings);
            }
            if (model.spells.length > 0) {
                yield actor.createOwnedItem(model.spells);
            }
            if (model.prayers.length > 0) {
                yield actor.createOwnedItem(model.prayers);
            }
            if (model.physicalMutations.length > 0) {
                yield actor.createOwnedItem(model.physicalMutations);
            }
            if (model.mentalMutations.length > 0) {
                yield actor.createOwnedItem(model.mentalMutations);
            }
            if ((_d = model === null || model === void 0 ? void 0 : model.options) === null || _d === void 0 ? void 0 : _d.withInitialMoney) {
                yield TrappingUtil.generateMoney(actor);
            }
            if (!((_e = model === null || model === void 0 ? void 0 : model.options) === null || _e === void 0 ? void 0 : _e.withLinkedToken) &&
                !((_f = model === null || model === void 0 ? void 0 : model.options) === null || _f === void 0 ? void 0 : _f.withInitialMoney) &&
                GenerateEffectOptionEnum.NONE !== model.options.generateMoneyEffect) {
                yield this.addGenerateTokenEffect(actor, 'WFRP4NPCGEN.trappings.money.label', GenerateEffectOptionEnum.DEFAULT_DISABLED ===
                    model.options.generateMoneyEffect, 'modules/wfrp4e-core/art/other/gold.webp');
            }
            const token = (_g = actor.data) === null || _g === void 0 ? void 0 : _g.token;
            const update = {};
            let performUpdate = false;
            if (token != null &&
                ((_h = model.options) === null || _h === void 0 ? void 0 : _h.tokenPath) != null &&
                model.options.tokenPath.length > 0) {
                performUpdate = true;
                update.img = model.options.tokenPath;
                update.randomImg = model.options.tokenPath.includes('*');
            }
            if (token != null && ((_j = model.options) === null || _j === void 0 ? void 0 : _j.withLinkedToken)) {
                performUpdate = true;
                update.actorLink = (_k = model.options) === null || _k === void 0 ? void 0 : _k.withLinkedToken;
            }
            if (performUpdate) {
                actor = (yield actor.update({
                    token: mergeObject(token, update, { inplace: false }),
                }));
            }
            return Promise.resolve(actor);
        });
    }
    static addGenerateTokenEffect(actor, label, disabled, icon) {
        return __awaiter(this, void 0, void 0, function* () {
            const generateEffect = {
                icon: icon,
                label: game.i18n.localize(label),
                disabled: disabled,
            };
            generateEffect['flags.wfrp4e.effectApplication'] = 'actor';
            yield actor.createEmbeddedEntity('ActiveEffect', generateEffect);
        });
    }
}
//# sourceMappingURL=creature-builder.js.map